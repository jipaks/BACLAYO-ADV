import { View, Text, TextInput, Button, StyleSheet } from "react-native";

export default function Home(){

    return (
        <View>
            <Text>This is home</Text>

        </View>
    )
}
